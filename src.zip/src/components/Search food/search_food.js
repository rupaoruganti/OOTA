import React from 'react';
import './search_food.css'; // Import the CSS file for styling

const SearchFood = () => {
  return (
    <div className="hero-section">
      <h1 className="hero-title">What do you wanna eat today?</h1>
     
    </div>
  );
};

export default SearchFood;
